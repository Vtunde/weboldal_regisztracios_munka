function ellenor()

	{

		ev   = parseInt(user.sz_ev.value)
		ir   = parseInt(user.irszam.value)
		cim  = user.mail.value

		ok = true

		if(cim.length  == 0)               { alert('Nem adtad meg az e-mail c�med!')       ;  ok = false  }  else

		if(cim.indexOf('@')    <  1                            ||
		   cim.indexOf('@')   !=  cim.lastIndexOf('@')         ||
		  -cim.indexOf('@')    +  cim.lastIndexOf('.') <  2    ||
		   cim.length-1        -  cim.lastIndexOf('.') <  2    ||
		   cim.length-1        -  cim.lastIndexOf('.') >  3    ||
		   cim.substr(cim.indexOf('@')-1, 1)          == '.'   ||
		   cim.substr(cim.indexOf('@')+1, 1)          == '.'      )

			                           { alert('Hib�s e-mail c�met adt�l!')            ;  ok = false  }  else


		if(user.pw.value.length == 0)      { alert('Nem adtál meg jelszót!')               ;  ok = false  }  else
		if(user.pw.value.length <  4)      { alert('A jelszó minimum 4 betű kell legyen!') ;  ok = false  }  else

		if(user.pw.value!=user.pw2.value)  { alert('Nem egyeznek a jelszavaid!')           ;  ok = false  }  else

		most=new Date()
		ezev=most.getYear()
		if(isNaN(ev) || ev<1900||ev>ezev)  { alert('Hibás a születési évszámod!')          ;  ok = false  }  else

		if(isNaN(ir) || ir<1011         )  { alert('Hibás irányítószámot írtál!')          ;  ok = false  }  else

		if(!(user.suli[0].checked) &&
		   !(user.suli[1].checked) &&
		   !(user.suli[2].checked)      )  { alert('Nem adtad meg a végzettséged!')        ;  ok = false  }  else

		if(!user.feltetel.checked       )  { alert('A feltételeket el kell fogadnod!')     ;  ok = false  }


		return ok

	}