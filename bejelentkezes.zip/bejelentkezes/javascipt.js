document.getElementById('loginForm').onsubmit = function(event) {
    
    event.preventDefault();
    var teljesnev= document.getElementById('teljesnev').value;
    var felhasznalo = document.getElementById('felhasznalo').value;
    var jelszo = document.getElementById('jelszo').value;
   
    alert('Felhasznalo: ' + felhasznalo + 'jelszo: ' + jelszo +'Teljesnev'+teljesnev);
};